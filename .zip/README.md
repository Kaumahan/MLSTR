# Ace Counter Pick

A floating bubble for Mobile Legends drafts. Open the app once to grant "Display over other apps", and the bubble floats on its own from then on. Tap it, type the enemy hero, and see:

- **Counter picks by lane**: the enemy's own lane first (EXP vs EXP, Gold vs Gold…), then Jungle, Mid, Roam, ranked by real win-rate edge
- **Don't pick into**: heroes that lose to it
- **Countered by** (in-game guide) and **Pairs well with**
- **Popular build**: core items with icons, emblem and battle spell, per lane
- **Team tab**: add 2–5 enemy picks and get heroes that are good against the whole team (average win-rate edge, "good into 4 of 5"), best pick per lane, and picks to avoid
- **Rank filter**: All / Epic / Legend / Mythic / Mythical Honor / Mythical Glory, remembered between sessions
- **Why it counters**: each counter pick shows its win rate in the matchup plus short reasons from official skill tags ("Strong crowd control catches Fanny's dashes")
- **First Pick tab**: highest win-rate heroes per lane (last 7 days)
- Typo-tolerant, instant search with hero icons ("lucas" → Lukas, "fany" → Fanny, "gold" → all Gold laners)

Drag the bubble onto the **X** at the bottom centre to close it.

## Data
Live from the Rone Arena API (https://arena.rone.dev, data © Moonton). Unofficial.
Cached on the phone (hero list 12 h, matchups 6 h, builds 12 h). A full snapshot ships in `app/src/main/assets/roster_seed.json` so it works offline on first launch.

## Build
- Debug APK: push to GitHub → Actions → **Build debug APK** → artifact **app-debug**
- Play release: see **PLAY_STORE_RELEASE.md**
- Local: `gradle testDebugUnitTest assembleDebug` (JDK 17, Android SDK 36)
